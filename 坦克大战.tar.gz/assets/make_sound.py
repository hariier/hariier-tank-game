import wave
import struct
import math

def generate_shoot_sound():
    sample_rate = 44100
    duration = 0.15  # 音效长度 0.15 秒
    
    # 创建一个 wav 文件
    with wave.open('shoot.wav', 'w') as wav_file:
        wav_file.setnchannels(1)     # 单声道
        wav_file.setsampwidth(2)     # 16位
        wav_file.setframerate(sample_rate)
        
        # 生成一段频率从高到低滑音的“Biubiubiu”声
        for i in range(int(sample_rate * duration)):
            progress = i / (sample_rate * duration)
            current_freq = 1200 - (1000 * progress) # 频率骤降产生开火感
            value = int(32767.0 * 0.4 * math.sin(2.0 * math.pi * current_freq * (i / sample_rate)))
            data = struct.pack('<h', value)
            wav_file.writeframesraw(data)
            
    print("生成成功！快去看看文件夹里是不是多了一个 shoot.wav！")

if __name__ == "__main__":
    generate_shoot_sound()