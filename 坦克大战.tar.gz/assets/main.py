import pygame
import sys
import random

# 初始化 Pygame
pygame.init()

# 游戏常量设置
WIDTH, HEIGHT = 800, 600
TILE_SIZE = 40
FPS = 60

# 颜色定义
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
BRICK_COLOR = (180, 80, 50)
STEEL_COLOR = (150, 150, 150)
BASE_COLOR = (0, 255, 0)
PLAYER_COLOR = (0, 150, 255)

# WYL 身份标识与基地地图 (1:砖块可碎, 2:钢铁不可碎, B:基地)
GAME_MAP = [
    "                    ",
    "                    ",
    "  1 1 1  2   2  1   ",
    "  1 1 1   2 2   1   ",
    "   1 1     2    1   ",
    "   1 1     2    111 ",
    "                    ",
    "                    ",
    "                    ",
    "                    ",
    "                    ",
    "                    ",
    "                    ",
    "         111        ",
    "         1B1        "
]

class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, wall_type):
        super().__init__()
        self.wall_type = wall_type
        self.image = pygame.Surface((TILE_SIZE, TILE_SIZE))
        
        if self.wall_type == '1': # 红砖墙
            self.image.fill(BRICK_COLOR)
            # 绘制砖块缝隙纹理
            pygame.draw.line(self.image, (130, 40, 20), (0, TILE_SIZE//2), (TILE_SIZE, TILE_SIZE//2), 2)
            pygame.draw.line(self.image, (130, 40, 20), (TILE_SIZE//2, 0), (TILE_SIZE//2, TILE_SIZE//2), 2)
            pygame.draw.line(self.image, (130, 40, 20), (TILE_SIZE//4, TILE_SIZE//2), (TILE_SIZE//4, TILE_SIZE), 2)
            pygame.draw.line(self.image, (130, 40, 20), (TILE_SIZE*3//4, TILE_SIZE//2), (TILE_SIZE*3//4, TILE_SIZE), 2)
            
        elif self.wall_type == '2': # 钢铁墙
            self.image.fill(STEEL_COLOR)
            # 绘制金属高光和边框
            pygame.draw.rect(self.image, (200, 200, 200), (0, 0, TILE_SIZE, TILE_SIZE), 3)
            pygame.draw.line(self.image, (255, 255, 255), (0, 0), (TILE_SIZE, TILE_SIZE), 2)
            pygame.draw.circle(self.image, (100, 100, 100), (TILE_SIZE//2, TILE_SIZE//2), 4)
            
        elif self.wall_type == 'B': # 基地
            self.image.fill((30, 30, 30))
            # 绘制一个简单的绿色雷达/老鹰标志作为基地
            pygame.draw.polygon(self.image, BASE_COLOR, [(TILE_SIZE//2, 5), (TILE_SIZE-5, TILE_SIZE-10), (5, TILE_SIZE-10)])
            
        self.rect = self.image.get_rect(topleft=(x, y))

class Tank(pygame.sprite.Sprite):
    def __init__(self, x, y, color, speed):
        super().__init__()
        self.base_color = color
        self.speed = speed
        self.direction = 'UP'
        self.image = pygame.Surface((TILE_SIZE - 4, TILE_SIZE - 4), pygame.SRCALPHA)
        self.update_image() # 初始化时绘制坦克形状
        self.rect = self.image.get_rect(center=(x, y))

    def update_image(self):
        """根据当前方向重绘坦克的外观（履带、车身、炮管）"""
        self.image.fill((0,0,0,0)) # 清空透明背景
        w, h = self.image.get_width(), self.image.get_height()
        track_color = (100, 100, 100)
        barrel_color = (200, 200, 200)

        if self.direction in ['UP', 'DOWN']:
            # 垂直履带
            pygame.draw.rect(self.image, track_color, (0, 0, 8, h))
            pygame.draw.rect(self.image, track_color, (w-8, 0, 8, h))
            pygame.draw.rect(self.image, self.base_color, (6, 4, w-12, h-8)) # 车身
            # 炮管
            if self.direction == 'UP':
                pygame.draw.rect(self.image, barrel_color, (w//2-2, 0, 4, h//2))
            else:
                pygame.draw.rect(self.image, barrel_color, (w//2-2, h//2, 4, h//2))
        else:
            # 水平履带
            pygame.draw.rect(self.image, track_color, (0, 0, w, 8))
            pygame.draw.rect(self.image, track_color, (0, h-8, w, 8))
            pygame.draw.rect(self.image, self.base_color, (4, 6, w-8, h-12)) # 车身
            # 炮管
            if self.direction == 'LEFT':
                pygame.draw.rect(self.image, barrel_color, (0, h//2-2, w//2, 4))
            else:
                pygame.draw.rect(self.image, barrel_color, (w//2, h//2-2, w//2, 4))

    def set_direction(self, new_dir):
        """改变方向并触发贴图更新"""
        if self.direction != new_dir:
            self.direction = new_dir
            self.update_image()

    def move(self, dx, dy, walls):
        # 移动逻辑保持原样不变
        self.rect.x += dx
        for wall in walls:
            if self.rect.colliderect(wall.rect):
                if dx > 0: self.rect.right = wall.rect.left
                if dx < 0: self.rect.left = wall.rect.right
        
        self.rect.y += dy
        for wall in walls:
            if self.rect.colliderect(wall.rect):
                if dy > 0: self.rect.bottom = wall.rect.top
                if dy < 0: self.rect.top = wall.rect.bottom

        self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))

class EnemyTank(Tank):
    def __init__(self, x, y, color, speed):
        super().__init__(x, y, color, speed)
        self.direction_timer = 0
        self.fire_timer = 0
        # 初始随机方向
        self.set_direction(random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT']))

    def update_ai(self, walls, enemy_bullets):
        self.direction_timer -= 1
        self.fire_timer -= 1

        # 1. 随机改变方向
        if self.direction_timer <= 0:
            self.set_direction(random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT']))
            self.direction_timer = random.randint(30, 90) # 维持该方向 0.5 到 1.5 秒

        # 2. 根据当前方向移动
        dx, dy = 0, 0
        if self.direction == 'UP': dy = -self.speed
        elif self.direction == 'DOWN': dy = self.speed
        elif self.direction == 'LEFT': dx = -self.speed
        elif self.direction == 'RIGHT': dx = self.speed

        # 记录移动前的位置
        old_x, old_y = self.rect.x, self.rect.y
        
        self.move(dx, 0, walls)
        self.move(0, dy, walls)
        
        # 如果移动后位置没变，说明撞墙了，立刻重置计时器触发转向
        if self.rect.x == old_x and self.rect.y == old_y:
            self.direction_timer = 0

        # 3. 随机开火
        if self.fire_timer <= 0:
            bullet = Bullet(self.rect.centerx, self.rect.centery, self.direction)
            enemy_bullets.add(bullet)
            self.fire_timer = random.randint(60, 150) # 每 1 到 2.5 秒射击一次

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        super().__init__()
        self.image = pygame.Surface((6, 6))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 7
        self.direction = direction

    def update(self):
        if self.direction == 'UP': self.rect.y -= self.speed
        elif self.direction == 'DOWN': self.rect.y += self.speed
        elif self.direction == 'LEFT': self.rect.x -= self.speed
        elif self.direction == 'RIGHT': self.rect.x += self.speed
        if self.rect.bottom < 0 or self.rect.top > HEIGHT or self.rect.right < 0 or self.rect.left > WIDTH:
            self.kill()

def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("坦克大战 - WYL 专属版")
    pygame.key.stop_text_input()
    clock = pygame.time.Clock()

    # 尝试加载底图
    try:
        bg_img = pygame.image.load("background.png")
        bg_img = pygame.transform.scale(bg_img, (WIDTH, HEIGHT))
    except:
        bg_img = None

    # 尝试加载音效（如果没有文件，后台会静默忽略，不影响游玩）
    try:
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        shoot_sound = pygame.mixer.Sound("shoot.wav")
        shoot_sound.set_volume(0.3) 
    except:
        shoot_sound = None

    font = pygame.font.Font(None, 74)
    ui_font = pygame.font.Font(None, 36)

    # --- 新增：最外层的“战局循环” ---
    while True: 
        walls = pygame.sprite.Group()
        player_bullets = pygame.sprite.Group() 
        enemy_bullets = pygame.sprite.Group()  
        base = None

        # 解析地图并生成 WYL 障碍物
        for row_idx, row in enumerate(GAME_MAP):
            for col_idx, char in enumerate(row):
                if char in ['1', '2', 'B']:
                    wall = Wall(col_idx * TILE_SIZE, row_idx * TILE_SIZE, char)
                    walls.add(wall)
                    if char == 'B':
                        base = wall

        player = Tank(WIDTH // 2 - 100, HEIGHT - TILE_SIZE, PLAYER_COLOR, 3)
        enemies = pygame.sprite.Group()

        current_wave = 1
        enemies_to_spawn = 3      
        spawn_timer = 0           
        max_waves = 3             

        running = True
        game_over = False
        result_text = ""

        # 内层的“单局游戏循环”
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if not game_over:
                        if event.key == pygame.K_SPACE:
                            bullet = Bullet(player.rect.centerx, player.rect.centery, player.direction)
                            player_bullets.add(bullet)
                            if shoot_sound:
                                shoot_sound.play() # 播放开炮音效
                    else:
                        # --- 新增：游戏结束且按下 R 键时，结束当前单局循环 ---
                        if event.key == pygame.K_r:
                            running = False 

            if not game_over:
                # 玩家移动逻辑
                keys = pygame.key.get_pressed()
                dx, dy = 0, 0
                if keys[pygame.K_w]: dy = -player.speed; player.set_direction('UP')
                elif keys[pygame.K_s]: dy = player.speed; player.set_direction('DOWN')
                elif keys[pygame.K_a]: dx = -player.speed; player.set_direction('LEFT')
                elif keys[pygame.K_d]: dx = player.speed; player.set_direction('RIGHT')
                
                if dx != 0 or dy != 0:
                    player.move(dx, 0, walls)
                    player.move(0, dy, walls)

                # 敌人自动生成逻辑
                if enemies_to_spawn > 0:
                    spawn_timer -= 1
                    if spawn_timer <= 0:
                        spawn_x = random.choice([TILE_SIZE, WIDTH // 2, WIDTH - TILE_SIZE * 2])
                        spawn_y = TILE_SIZE
                        enemy_speed = 1.5 + current_wave * 0.3
                        new_enemy = EnemyTank(spawn_x, spawn_y, RED, enemy_speed)
                        enemies.add(new_enemy)
                        enemies_to_spawn -= 1
                        spawn_timer = 90
                elif len(enemies) == 0:
                    if current_wave >= max_waves:
                        game_over = True
                        result_text = "VICTORY!"
                    else:
                        current_wave += 1
                        enemies_to_spawn = 2 + current_wave * 2
                        spawn_timer = 120

                # 更新子弹与敌人 AI
                player_bullets.update()
                enemy_bullets.update()
                for e in enemies:
                    e.update_ai(walls, enemy_bullets)

                # 碰撞检测：玩家子弹
                for bullet in player_bullets:
                    hit_walls = pygame.sprite.spritecollide(bullet, walls, False)
                    for w in hit_walls:
                        bullet.kill()
                        if w.wall_type == '1': w.kill()
                        elif w.wall_type == 'B':
                            game_over = True
                            result_text = "DEFEAT: Base Destroyed"
                
                    if pygame.sprite.spritecollide(bullet, enemies, True):
                        bullet.kill()

                # 碰撞检测：敌人子弹
                for bullet in enemy_bullets:
                    hit_walls = pygame.sprite.spritecollide(bullet, walls, False)
                    for w in hit_walls:
                        bullet.kill()
                        if w.wall_type == '1': w.kill()
                        elif w.wall_type == 'B':
                            game_over = True
                            result_text = "DEFEAT: Base Destroyed"
                
                    if pygame.sprite.spritecollide(player, enemy_bullets, True):
                        bullet.kill()
                        game_over = True
                        result_text = "DEFEAT: Player Destroyed"

            # 画面绘制
            if bg_img:
                screen.blit(bg_img, (0, 0))
            else:
                screen.fill(BLACK)
                
            walls.draw(screen)
            
            if not game_over or result_text == "VICTORY!" or result_text == "DEFEAT: Base Destroyed":
                screen.blit(player.image, player.rect)
                
            for e in enemies:
                screen.blit(e.image, e.rect)
                
            player_bullets.draw(screen)
            enemy_bullets.draw(screen)

            wave_text = ui_font.render(f"Wave: {current_wave} / {max_waves}", True, WHITE)
            screen.blit(wave_text, (10, 10))

            if game_over:
                # 绘制胜负文字
                text_surface = font.render(result_text, True, WHITE)
                screen.blit(text_surface, (WIDTH//2 - text_surface.get_width()//2, HEIGHT//2 - 50))
                # --- 新增：绘制重玩提示文字 ---
                restart_text = ui_font.render("Press 'R' to Restart", True, WHITE)
                screen.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, HEIGHT//2 + 50))

            pygame.display.flip()
            clock.tick(FPS)

if __name__ == "__main__":
    main()